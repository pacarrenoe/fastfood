export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyCiMT3NI_5GeD1RCPr6ZlFx0g7xZv6avNQ",
    authDomain: "fastfood-pos-1.firebaseapp.com",
    projectId: "fastfood-pos-1",
    storageBucket: "fastfood-pos-1.firebasestorage.app",
    messagingSenderId: "24282129131",
    appId: "1:24282129131:web:31dd45186db2d338f794ae",
    measurementId: "G-DXP57TCBC8"
  }
};
